#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/talking-synth-editor"
exec npm run dev -- "$@"
