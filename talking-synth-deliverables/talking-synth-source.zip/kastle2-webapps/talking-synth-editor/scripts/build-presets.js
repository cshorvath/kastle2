import {writeFileSync,readFileSync} from 'node:fs';
import {encodePresets,defaultProject} from '../src/presets.js';
const [input,output]=process.argv.slice(2);
if(!output) throw Error('Usage: npm run presets -- defaults|project.json output.bin');
const project=input==='defaults'?defaultProject():JSON.parse(readFileSync(input,'utf8'));
writeFileSync(output,encodePresets(project));
