// Optional browser integration check; uses an existing Playwright installation.
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {decodePresets} from '../src/presets.js';
const {chromium}=await import(process.env.PLAYWRIGHT_MODULE || 'playwright');
const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||undefined,headless:true,args:['--no-sandbox']});
try {
 const page=await browser.newPage();const errors=[];
 page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(()=>{window.AudioContext=class {constructor(){throw Error('Unexpected audio preview');}};window.webkitAudioContext=window.AudioContext;});
 await page.goto(process.env.EDITOR_URL||'http://127.0.0.1:5173/talking-synth-editor/');
 await page.getByRole('heading',{name:/Phrase Editor/}).waitFor();
 await page.getByRole('textbox',{name:'Text',exact:true}).first().fill('HELLO FROM THE EDITOR');
 await page.getByLabel('speed',{exact:true}).first().fill('90');
 await page.getByLabel('Sing mode').first().check();
 await page.getByRole('button',{name:'+ Bank',exact:true}).click();
 await page.getByRole('button',{name:/1 · TALK/}).click();
 const jsonDownload=page.waitForEvent('download');await page.getByRole('button',{name:'Export JSON',exact:true}).click();
 const jsonFile=await (await jsonDownload).path();const project=JSON.parse(readFileSync(jsonFile,'utf8'));
 assert.equal(project.banks.length,2);assert.equal(project.banks[0].phrases[0].text,'HELLO FROM THE EDITOR');
 assert.equal(project.banks[0].phrases[0].speed,90);assert.equal(project.banks[0].phrases[0].sing,true);
 await page.getByLabel('Import preset JSON').setInputFiles({name:'bad.json',mimeType:'application/json',buffer:Buffer.from('{}')});
 await page.getByRole('alert').waitFor();assert.match(await page.getByRole('alert').textContent(),/Unsupported/);
 await page.getByLabel('Import preset JSON').setInputFiles(jsonFile);
 await page.getByRole('status').filter({hasText:'Preset banks imported.'}).waitFor();
 const firmware=process.env.FIRMWARE_UF2;
 if(!firmware)throw Error('Set FIRMWARE_UF2 to a built talking-synth firmware-only image.');
 await page.getByLabel('Select Talking Synth firmware').setInputFiles(firmware);
 await page.getByRole('status').filter({hasText:'Talking Synth firmware loaded.'}).waitFor();
 const uf2Download=page.waitForEvent('download');await page.getByRole('button',{name:'Generate flashable UF2'}).click();
 const output=readFileSync(await (await uf2Download).path());assert.equal(output.length%512,0);
 const chunks=[];for(let i=0;i<output.length;i+=512)if(output.readUInt32LE(i+12)>=0x10080000)chunks.push(output.subarray(i+32,i+288));
 const data=Buffer.concat(chunks),size=data.readUInt32LE(4),decoded=decodePresets(new Uint8Array(data.subarray(0,size)));
 assert.equal(decoded.banks[0].phrases[0].text,'HELLO FROM THE EDITOR');assert.equal(decoded.banks[0].phrases[0].speed,90);
 await page.setViewportSize({width:390,height:844});
 assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth),true);
 if(process.env.SCREENSHOT)await page.screenshot({path:process.env.SCREENSHOT,fullPage:true});
 assert.deepEqual(errors,[]);console.log('Browser smoke passed: editing, bank changes, JSON validation/import/export and flashable UF2 download; no audio context.');
} finally {await browser.close();}
