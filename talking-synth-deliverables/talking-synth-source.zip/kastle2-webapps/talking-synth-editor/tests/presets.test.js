import test from 'node:test';
import assert from 'node:assert/strict';
import {writeFileSync,readFileSync} from 'node:fs';
import {defaultProject,encodePresets,decodePresets,validateProject,crc32} from '../src/presets.js';
import {buildFirmware,inspectFirmware} from '../src/firmware.js';
const firmwarePath=new URL('../../../kastle2/code/build/output/kastle2-talking-synth.uf2',import.meta.url);
test('Preset round trip retains all banks, parameters, scales and rhythms',()=>{
 const p=defaultProject();p.banks[0].phrases[0]={text:'HELLO, WORLD!',speed:120,mouth:90,throat:210,sing:true};
 p.banks.push({...structuredClone(p.banks[0]),name:'ROBOT',color:'#00ff80'});
 assert.deepEqual(decodePresets(encodePresets(p)),p);
 const path=process.env.PRESET_FIXTURE;if(path)writeFileSync(path,encodePresets(p));
});
test('Reject invalid text, parameters, bank dimensions and JSON types',()=>{
 for(const change of [p=>p.banks[0].phrases[0].text='A'.repeat(64),p=>p.banks[0].phrases[0].text='ÁRVÍZ',p=>p.banks[0].phrases[0].text='[HELLO]',p=>p.banks[0].phrases[0].speed=0,p=>p.banks[0].phrases[0].speed=1.2,p=>p.banks[0].phrases[0].sing=1,p=>p.scales=[0],p=>p.rhythms=[-1],p=>p.sequencerLength=65,p=>p.banks.push({name:'A',color:'#ffffff',phrases:[]})]) {
  const p=defaultProject();change(p);assert.throws(()=>validateProject(p));
 }
 assert.throws(()=>validateProject(null));
});
test('Binary parser rejects corruption, truncation, version and malformed phrase',()=>{
 const bytes=encodePresets(defaultProject());
 assert.equal(crc32(new TextEncoder().encode('123456789')),0xcbf43926);
 assert.throws(()=>decodePresets(bytes.subarray(0,31)));
 for(const index of [0,4,8,12,14,bytes.length-1]) {const corrupt=bytes.slice();corrupt[index]^=0xff;assert.throws(()=>decodePresets(corrupt));}
 const corrupt=bytes.slice();corrupt[32+24+16+67]=2;new DataView(corrupt.buffer).setUint32(8,crc32(corrupt.subarray(32)),true);assert.throws(()=>decodePresets(corrupt));
});
test('Maximum bank dimensions encode safely and preserve maximum sequencer length',()=>{
 const p=defaultProject();p.sequencerLength=64;p.banks=Array.from({length:32},()=>({name:'MAXIMUM',color:'#abcdef',phrases:Array.from({length:32},()=>({...p.banks[0].phrases[0],text:'A'.repeat(63)}))}));
 assert.deepEqual(decodePresets(encodePresets(p)),p);
});
test('Combine actual firmware and presets into numbered nonoverlapping RP2040 UF2',async()=>{
 const firmware=new Uint8Array(readFileSync(firmwarePath));const oldCount=inspectFirmware(firmware);
 const p=defaultProject(),presets=encodePresets(p),blob=await buildFirmware(p,firmware);
 const output=new Uint8Array(await blob.arrayBuffer()),count=output.length/512;
 assert.equal(count,oldCount+Math.ceil(presets.length/256));
 const presetBytes=[];
 for(let i=0;i<count;i++) {
  const v=new DataView(output.buffer,i*512,512);
  assert.equal(v.getUint32(20,true),i);assert.equal(v.getUint32(24,true),count);assert.equal(v.getUint32(28,true),0xe48bff56);
  if(i<oldCount) assert.deepEqual(output.subarray(i*512+32,i*512+288),firmware.subarray(i*512+32,i*512+288));
  else {assert.equal(v.getUint32(12,true),0x10080000+(i-oldCount)*256);presetBytes.push(...output.subarray(i*512+32,i*512+288));}
 }
 assert.deepEqual(new Uint8Array(presetBytes).subarray(0,presets.length),presets);
 if(process.env.MERGED_FIXTURE)writeFileSync(process.env.MERGED_FIXTURE,output);
});
test('UF2 rejects wrong family, oversized payload, preset overlap, duplicates and other apps',()=>{
 const firmware=new Uint8Array(readFileSync(firmwarePath));
 for(const [offset,value] of [[28,0],[16,512],[12,0x10080000],[20,9],[24,0]]) {
  const corrupt=firmware.slice();new DataView(corrupt.buffer).setUint32(offset,value,true);assert.throws(()=>inspectFirmware(corrupt));
 }
 assert.throws(()=>inspectFirmware(new Uint8Array(0)));assert.throws(()=>inspectFirmware(firmware.subarray(0,20)));
 const duplicate=firmware.slice();new DataView(duplicate.buffer).setUint32(512+12,0x10000000,true);assert.throws(()=>inspectFirmware(duplicate));
 const other=new Uint8Array(readFileSync(new URL('../../../kastle2/code/build/output/kastle2-wave-bard.uf2',import.meta.url)));assert.throws(()=>inspectFirmware(other));
});
