# Talking Synth Editor

A React/Vite sibling to Wave Bard Sample Loader. It reuses the shared Header,
Button, SCSS tokens and UF2 writer/merger. It has no browser audio synthesis,
audio context, autoplay, or audio preview dependency.

## Develop and build

Use Node.js 20+ and npm. From the `kastle2-webapps` checkout:

```sh
cd shared/bastl-react && npm ci
cd ../../talking-synth-editor && npm ci
npm run dev
npm run build
```

The production build is `dist`, with base path `/talking-synth-editor/`. No
backend, credentials or external services are required. Text/presets are
processed locally. Changes are kept in memory; use JSON export to save them.

Select a bank, edit phrase text and voice parameters, add/remove banks or phrase
slots, and export/import the complete JSON project. All banks have the same slot
count. Adding/removing a phrase slot applies to every bank. Scale/rhythm tables
round-trip through JSON; the editor exposes sequencer length directly.

Select **kastle2-talking-synth.uf2** from a build of the companion firmware and
click **Generate flashable UF2**. The editor validates it as an RP2040 firmware-only
Talking Synth image, appends encoded presets at `0x10080000`, and downloads
`kastle2-talking-synth-with-presets.uf2`. It does not upload to the device or fetch
a bundled SAM firmware. Hold SHIFT while powering on the Kastle 2, then copy the
result to `RPI-RP2`. Binary presets can also be exported for the CMake merge target.

## Automated checks

Build the companion firmware first, in the sibling `kastle2` checkout:

```sh
cd /path/to/kastle2
cmake --build code/build --target talking-synth wave-bard --parallel 5
cd /path/to/kastle2-webapps/talking-synth-editor
PRESET_FIXTURE=/tmp/talking-preset-fixture.bin npm test
npm run build
cd /path/to/kastle2
PRESET_FIXTURE=/tmp/talking-preset-fixture.bin bash code/tests/talking-synth/run.sh
```

The fixture environment variable connects the JS writer to the real C++ firmware
parser. Tests use actual firmware files from the sibling checkout. `wave-bard`
is built only as a negative fixture for rejecting the wrong application image.

Optional Chromium smoke test (start the dev server in a separate terminal):

```sh
# Use an existing Playwright / playwright-core installation; no runtime app dependency.
PLAYWRIGHT_MODULE=/absolute/path/to/playwright-core/index.mjs \
CHROMIUM_PATH=/usr/bin/chromium \
FIRMWARE_UF2=/path/to/kastle2/code/build/output/kastle2-talking-synth.uf2 \
node scripts/browser-smoke.mjs
```

It checks visible editing, bank addition, JSON export/import/error handling,
firmware loading, downloaded UF2 preset content, mobile overflow, browser
exceptions and absence of audio context creation. `EDITOR_URL` overrides the
local test address; `SCREENSHOT` optionally saves the mobile screenshot.

For command-line preset generation:

```sh
npm run presets -- defaults /path/to/PRESETS.bin
npm run presets -- exported-banks.json /path/to/PRESETS.bin
```

See the companion firmware's `PRESET_FORMAT.md`, `README.md` and
`THIRD_PARTY.md` under `code/src/apps/TalkingSynth`. SAM has **no open-source
redistribution license**, and Bastl graphics retain their original rights. The
new editor code follows this repository's MIT terms, which do not license SAM
or the graphics. This work has not been deployed or published.
