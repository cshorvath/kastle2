// SPDX-License-Identifier: MIT
import {useState} from 'react';
import Header from '@bastl-react/components/Header';
import Button from '@bastl-react/components/Button';
import {defaultProject,defaultPhrase,validateProject,encodePresets} from './presets.js';
import {buildFirmware,inspectFirmware} from './firmware.js';
function download(name,data,type) {
  const url=URL.createObjectURL(data instanceof Blob?data:new Blob([data],{type}));
  const a=document.createElement('a');a.href=url;a.download=name;a.click();
  setTimeout(()=>URL.revokeObjectURL(url),1000);
}
export default function App() {
  const [project,setProject]=useState(defaultProject),[bankIndex,setBankIndex]=useState(0);
  const [firmware,setFirmware]=useState(null),[firmwareName,setFirmwareName]=useState('');
  const [message,setMessage]=useState(''),[error,setError]=useState(''),[busy,setBusy]=useState(false);
  const bank=project.banks[bankIndex];
  const update=fn=>setProject(old=>{const next=structuredClone(old);fn(next);return next;});
  const updatePhrase=(index,key,value)=>update(p=>{p.banks[bankIndex].phrases[index][key]=value;});
  const run=async action=>{setError('');setMessage('');try{await action();}catch(e){setError(e.message);}};
  async function importJson(event) {
    const file=event.target.files?.[0];event.target.value='';if(!file)return;
    await run(async()=>{if(file.size>1024*1024)throw Error('JSON file exceeds 1 MB.');const value=validateProject(JSON.parse(await file.text()));setProject(value);setBankIndex(0);setMessage('Preset banks imported.');});
  }
  async function loadFirmware(event) {
    const file=event.target.files?.[0];event.target.value='';if(!file)return;
    await run(async()=>{if(file.size>1024*1024)throw Error('Firmware-only UF2 exceeds 1 MB.');const bytes=new Uint8Array(await file.arrayBuffer());inspectFirmware(bytes);setFirmware(bytes);setFirmwareName(file.name);setMessage('Talking Synth firmware loaded.');});
  }
  async function generate() {
    setBusy(true);
    await run(async()=>{validateProject(project);if(!firmware)throw Error('Select a Talking Synth firmware-only UF2 first.');const blob=await buildFirmware(project,firmware);download('kastle2-talking-synth-with-presets.uf2',blob);setMessage('UF2 generated. Power on with SHIFT held, then copy it to RPI-RP2.');});
    setBusy(false);
  }
  return <main>
    <Header title={<>Talking Synth<br/>Phrase Editor</>}/>
    <section className="intro"><p>Text becomes your instrument. SAMPLE chooses a phrase; BANK chooses its voice bank.</p><p>Pitch follows the patch. Speaking speed belongs to each preset.</p></section>
    <nav className="toolbar" aria-label="Project files">
      <label className="file-button">Import JSON<input aria-label="Import preset JSON" type="file" accept=".json,application/json" onChange={importJson}/></label>
      <Button onClick={()=>run(()=>{validateProject(project);download('talking-synth-banks.json',JSON.stringify(project,null,2),'application/json');})}>Export JSON</Button>
      <Button onClick={()=>run(()=>download('PRESETS.bin',encodePresets(project),'application/octet-stream'))}>Export presets</Button>
    </nav>
    {error&&<p role="alert" className="error">{error}</p>}
    <p role="status" aria-live="polite">{message}</p>
    <section className="panel">
      <div className="section-heading"><h2>Phrase banks</h2><span>{project.banks.length}/32 BANKS · {bank.phrases.length}/32 PHRASES EACH</span></div>
      <nav className="banks" aria-label="Phrase banks">{project.banks.map((b,i)=><Button key={i} active={i===bankIndex} onClick={()=>setBankIndex(i)} style={{borderColor:b.color}}>{i+1} · {b.name}</Button>)}
        <Button disabled={project.banks.length===32} onClick={()=>{update(p=>p.banks.push({name:'NEW',color:'#2869fb',phrases:bank.phrases.map(()=>defaultPhrase())}));setBankIndex(project.banks.length);}}>+ Bank</Button>
      </nav>
      <div className="bank-settings"><label>Bank name<input maxLength={8} value={bank.name} onChange={e=>update(p=>{p.banks[bankIndex].name=e.target.value;})}/></label><label>LED color<input type="color" value={bank.color} onChange={e=>update(p=>{p.banks[bankIndex].color=e.target.value;})}/></label>
        <Button disabled={project.banks.length===1} onClick={()=>{update(p=>p.banks.splice(bankIndex,1));setBankIndex(Math.max(0,bankIndex-1));}}>Remove bank</Button></div>
      <div className="phrases">{bank.phrases.map((phrase,i)=><article className="phrase" key={i}>
        <div className="phrase-title"><h3>Phrase {String(i+1).padStart(2,'0')}</h3><Button disabled={bank.phrases.length===1} onClick={()=>update(p=>p.banks.forEach(b=>b.phrases.splice(i,1)))}>Remove slot</Button></div>
        <label>Text<textarea maxLength={63} value={phrase.text} onChange={e=>updatePhrase(i,'text',e.target.value)} aria-describedby="text-help"/></label>
        <div className="voice-controls">{['speed','mouth','throat'].map(key=><label key={key}>{key}<input type="number" min="1" max="255" value={phrase[key]} onChange={e=>updatePhrase(i,key,e.target.value===''?'':Number(e.target.value))}/></label>)}
          <label className="checkbox"><input type="checkbox" checked={phrase.sing} onChange={e=>updatePhrase(i,'sing',e.target.checked)}/>Sing mode</label></div>
      </article>)}</div>
      <Button disabled={bank.phrases.length===32} onClick={()=>update(p=>p.banks.forEach(b=>b.phrases.push(defaultPhrase())))}>+ Phrase slot in every bank</Button>
      <p id="text-help">1–63 English letters, numbers, spaces and punctuation. Higher SPEED values speak more slowly. Removing a slot removes it from every bank.</p>
    </section>
    <section className="panel"><h2>Sequencer</h2><label>Steps<input type="number" min="2" max="64" value={project.sequencerLength} onChange={e=>update(p=>{p.sequencerLength=Number(e.target.value);})}/></label><p>Scale and rhythm tables are preserved through JSON import/export. Default tables provide chromatic, major and minor scales.</p></section>
    <section className="panel export"><h2>Make your firmware</h2><p>Choose the <strong>talking-synth</strong> firmware-only UF2 built from the companion repository. Your text and voice settings will be added to its preset region.</p>
      <label className="file-button">Select firmware UF2<input aria-label="Select Talking Synth firmware" type="file" accept=".uf2" onChange={loadFirmware}/></label><span>{firmwareName||'No firmware selected'}</span>
      <Button disabled={!firmware||busy} onClick={generate}>{busy?'Generating…':'Generate flashable UF2'}</Button>
      <p>With the device powered off, hold SHIFT and power it on. Copy the generated UF2 to the RPI-RP2 drive. Flashing replaces the installed firmware and preset data.</p>
    </section>
    <footer><p>Custom Kastle 2 / Citadel firmware. Test on hardware before performance use.</p><p>SAM has no open-source redistribution license. Consult the accompanying third-party notice before sharing firmware. Bastl graphics retain their original rights.</p></footer>
  </main>;
}
