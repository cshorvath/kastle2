// SPDX-License-Identifier: MIT
export const HEADER=32, BANK=16, PHRASE=80, MAX_SIZE=7680*1024;
export const defaultPhrase=()=>({text:'HELLO KASTLE',speed:72,mouth:128,throat:128,sing:false});
export const defaultProject=()=>({format:'kastle2-talking-synth',version:1,sequencerLength:16,
  scales:[0xfff,0xab5,0x5ad],rhythms:[0x8888,0xaaaa,0xffff],
  banks:[{name:'TALK',color:'#ffed33',phrases:[defaultPhrase(),{...defaultPhrase(),text:'I AM A TALKING SYNTH'}]}]});
const integer=(x,min,max)=>Number.isInteger(x)&&x>=min&&x<=max;
export function validateProject(project) {
  if (!project || project.format!=='kastle2-talking-synth'||project.version!==1) throw Error('Unsupported Talking Synth JSON format or version.');
  if (!integer(project.sequencerLength,2,64)) throw Error('Sequencer length must be 2–64.');
  if (!Array.isArray(project.scales)||project.scales.length<1||project.scales.length>32||project.scales.some(x=>!integer(x,1,0xfff))) throw Error('Provide 1–32 nonempty 12-bit scales.');
  if (!Array.isArray(project.rhythms)||project.rhythms.length<1||project.rhythms.length>64||project.rhythms.some(x=>!integer(x,0,0xffffffff))) throw Error('Provide 1–64 unsigned 32-bit rhythms.');
  if (!Array.isArray(project.banks)||project.banks.length<1||project.banks.length>32) throw Error('Provide 1–32 banks.');
  const count=project.banks[0]?.phrases?.length;
  if (!integer(count,1,32)) throw Error('Provide 1–32 phrases per bank.');
  for (const bank of project.banks) {
    if (typeof bank.name!=='string'||!bank.name.length||bank.name.length>8||!/^[\x20-\x7e]+$/.test(bank.name)) throw Error('Bank names must have 1–8 ASCII characters.');
    if (!/^#[0-9a-f]{6}$/i.test(bank.color)) throw Error('Invalid bank color.');
    if (!Array.isArray(bank.phrases)||bank.phrases.length!==count) throw Error('Every bank must have the same number of phrases.');
    for (const phrase of bank.phrases) {
      if (typeof phrase.text!=='string'||phrase.text.length<1||phrase.text.length>63||!/^[A-Za-z0-9 .,?!'\-]+$/.test(phrase.text)||!phrase.text.trim()) throw Error('Phrase text must contain 1–63 English ASCII letters, digits, spaces or punctuation (.,?!\' -).');
      for (const key of ['speed','mouth','throat']) if (!integer(phrase[key],1,255)) throw Error(`${key} must be an integer from 1 to 255.`);
      if (typeof phrase.sing!=='boolean') throw Error('Sing mode must be a boolean.');
    }
  }
  return project;
}
export function crc32(bytes) {
  let crc=0xffffffff;
  for(const byte of bytes) {crc^=byte; for(let i=0;i<8;i++) crc=(crc>>>1)^((crc&1)?0xedb88320:0);}
  return (~crc)>>>0;
}
export function encodePresets(project) {
  validateProject(project);
  const count=project.banks[0].phrases.length;
  const size=HEADER+4*(project.scales.length+project.rhythms.length)+project.banks.length*(BANK+count*PHRASE)+4;
  if(size>MAX_SIZE) throw Error('Preset data exceeds flash capacity.');
  const bytes=new Uint8Array(size),view=new DataView(bytes.buffer),encoder=new TextEncoder();
  bytes.set(encoder.encode('k2ts')); view.setUint32(4,size,true); view.setUint16(12,1,true);
  bytes.set([project.banks.length,count,project.scales.length,project.rhythms.length,project.sequencerLength],14);
  let offset=HEADER;
  for(const value of [...project.scales,...project.rhythms]) {view.setUint32(offset,value,true);offset+=4;}
  for(const bank of project.banks) {
    bytes.set(encoder.encode(bank.name),offset);
    for(let i=0;i<3;i++) bytes[offset+8+i]=parseInt(bank.color.slice(1+i*2,3+i*2),16);
    offset+=BANK;
    for(const p of bank.phrases) {
      bytes.set(encoder.encode(p.text.toUpperCase()),offset);
      bytes.set([p.speed,p.mouth,p.throat,p.sing?1:0],offset+64);offset+=PHRASE;
    }
  }
  bytes.set(encoder.encode('ahoj'),offset); view.setUint32(8,crc32(bytes.subarray(HEADER)),true);
  return bytes;
}
export function decodePresets(bytes) {
  if (!(bytes instanceof Uint8Array)||bytes.length<36) throw Error('Truncated preset file.');
  const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),decoder=new TextDecoder();
  if(decoder.decode(bytes.subarray(0,4))!=='k2ts'||view.getUint32(4,true)!==bytes.length||view.getUint16(12,true)!==1||view.getUint32(8,true)!==crc32(bytes.subarray(HEADER))||decoder.decode(bytes.subarray(-4))!=='ahoj') throw Error('Invalid preset header, CRC or trailer.');
  const [banks,count,scales,rhythms,sequencerLength]=bytes.subarray(14,19);
  const size=HEADER+4*(scales+rhythms)+banks*(BANK+count*PHRASE)+4;
  if(size!==bytes.length||size>MAX_SIZE) throw Error('Invalid preset dimensions.');
  let offset=HEADER;
  const readWords=n=>Array.from({length:n},()=>{const v=view.getUint32(offset,true);offset+=4;return v;});
  const project={format:'kastle2-talking-synth',version:1,sequencerLength,scales:readWords(scales),rhythms:readWords(rhythms),banks:[]};
  const readText=(start,length)=>{const b=bytes.subarray(start,start+length);const end=b.indexOf(0);return decoder.decode(end<0?b:b.subarray(0,end));};
  for(let b=0;b<banks;b++) {
    const bank={name:readText(offset,8),color:'#'+Array.from(bytes.subarray(offset+8,offset+11),v=>v.toString(16).padStart(2,'0')).join(''),phrases:[]}; offset+=BANK;
    for(let p=0;p<count;p++) {
      if(bytes[offset+67]>1||bytes.subarray(offset,offset+64).indexOf(0)<0) throw Error('Invalid phrase record.');
      bank.phrases.push({text:readText(offset,64),speed:bytes[offset+64],mouth:bytes[offset+65],throat:bytes[offset+66],sing:!!bytes[offset+67]});offset+=PHRASE;
    }
    project.banks.push(bank);
  }
  return validateProject(project);
}
