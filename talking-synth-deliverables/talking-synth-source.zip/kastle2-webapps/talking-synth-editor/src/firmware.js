// SPDX-License-Identifier: MIT
// Reuse the existing Web Apps writer/merger after strict input validation.
import {generateUf2,mergeUf2,UF2_FAMILY_ID,USER_DATA_BEGIN,PROGRAM_MAX_SIZE} from '../../shared/bastl-react/utils/uf2Utils.js';
import {encodePresets} from './presets.js';
export function inspectFirmware(bytes) {
  if(!(bytes instanceof Uint8Array)||!bytes.length||bytes.length%512) throw Error('Firmware must be a nonempty UF2 file.');
  const blocks=bytes.length/512, seen=new Set(); let boot=false;
  // Reject other Kastle apps using the embedded binary program identity.
  const marker=new TextEncoder().encode('talking-synth');
  const payloads=[];
  for(let i=0;i<blocks;i++) {
    const v=new DataView(bytes.buffer,bytes.byteOffset+i*512,512);
    const addr=v.getUint32(12,true),size=v.getUint32(16,true);
    if(v.getUint32(0,true)!==0x0a324655||v.getUint32(4,true)!==0x9e5d5157||v.getUint32(508,true)!==0x0ab16f30||v.getUint32(8,true)!==0x2000||v.getUint32(28,true)!==UF2_FAMILY_ID) throw Error('Invalid RP2040 UF2 block.');
    if(size!==256||addr%256||addr<0x10000000||addr+size>0x10000000+PROGRAM_MAX_SIZE) throw Error('Upload the Talking Synth firmware-only UF2 (no preset region).');
    if(v.getUint32(20,true)!==i||v.getUint32(24,true)!==blocks||seen.has(addr)) throw Error('Invalid or duplicated UF2 block sequence.');
    seen.add(addr); if(addr===0x10000000) boot=true;
    payloads.push({addr,data:bytes.subarray(i*512+32,i*512+288)});
  }
  if(!boot) throw Error('Firmware is missing the boot block.');
  payloads.sort((a,b)=>a.addr-b.addr);
  const image=new Uint8Array(PROGRAM_MAX_SIZE);
  for(const p of payloads) image.set(p.data,p.addr-0x10000000);
  let found=false;
  outer: for(let i=0;i<=image.length-marker.length;i++) {
    for(let j=0;j<marker.length;j++) if(image[i+j]!==marker[j]) continue outer;
    found=true;break;
  }
  if(!found) throw Error('This firmware does not identify as Talking Synth.');
  return blocks;
}
export async function buildFirmware(project,firmware) {
  inspectFirmware(firmware);
  const data=generateUf2(UF2_FAMILY_ID,USER_DATA_BEGIN,encodePresets(project));
  return mergeUf2([new Blob([firmware]),data],false);
}
