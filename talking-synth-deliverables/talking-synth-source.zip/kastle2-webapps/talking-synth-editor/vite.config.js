import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';
import {fileURLToPath} from 'node:url';
export default defineConfig({
  base: '/talking-synth-editor/', plugins: [react()],
  resolve: {alias: {'@bastl-react':fileURLToPath(new URL('../shared/bastl-react',import.meta.url))}, dedupe:['react','react-dom','prop-types','classnames','loglevel']}
});
