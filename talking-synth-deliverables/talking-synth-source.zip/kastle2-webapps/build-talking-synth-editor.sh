#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/talking-synth-editor"
npm run build
